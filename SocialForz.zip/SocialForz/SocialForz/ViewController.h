//
//  ViewController.h
//  SocialForz
//
//  Created by Bluesky on 4/10/15.
//  Copyright (c) 2015 Bluesky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>{

    IBOutlet UIView *bgView;
    IBOutlet UIView *emailView;
    IBOutlet UIView *pwdView;
    IBOutlet UIButton *loginBtn;
    IBOutlet UITextField *emailField;
    IBOutlet UITextField *pwdField;
}
- (IBAction)loginBtnClicked:(id)sender;


@end

