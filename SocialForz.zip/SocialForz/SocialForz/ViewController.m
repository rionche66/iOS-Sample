//
//  ViewController.m
//  SocialForz
//
//  Created by Bluesky on 4/10/15.
//  Copyright (c) 2015 Bluesky. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD.h"

#import <Parse/Parse.h>

@interface ViewController ()

@property (nonatomic, strong) MBProgressHUD *hud;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    bgView.layer.cornerRadius = 4.0f;
    bgView.layer.masksToBounds = YES;
    
    emailView.layer.cornerRadius = 7.0f;
    emailView.layer.masksToBounds = YES;
    emailView.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    emailView.layer.borderWidth = 1.0f;
    
    pwdView.layer.cornerRadius = 7.0f;
    pwdView.layer.masksToBounds = YES;
    pwdView.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    pwdView.layer.borderWidth = 1.0f;
    
    loginBtn.layer.cornerRadius = 7.0f;
    loginBtn.layer.masksToBounds = YES;
    
    //temp
//    emailField.text = @"tester";
//    pwdField.text = @"qwerqwer";
    NSInteger isUser = [[[NSUserDefaults standardUserDefaults] objectForKey:@"login"]integerValue];
     NSLog(@"login %ld", (long)isUser);
    if (isUser == 1) {
        [self loginSuccess];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)loginBtnClicked:(id)sender {
    if([emailField.text isEqualToString:@""] || [pwdField.text isEqualToString:@""]) {
        [self createAlertView:@"Please input your email or password."];
        return;
    }
    self.hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [PFUser logInWithUsernameInBackground:emailField.text password:pwdField.text block:^(PFUser *user, NSError *error) {
        if (user) {
            NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
            if ([user[@"token"] isEqualToString:uniqueIdentifier]) {
                [self loginSuccess];
            }else if (user[@"token"] == nil){
                user[@"token"] = uniqueIdentifier;
                [user saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                    if (succeeded){
                        [self loginSuccess];
                    }
                    else{
                        NSString *errorString = [[error userInfo] objectForKey:@"error"];
                        [self createAlertView:errorString];
                    }
                }];
            }else{
                [self createAlertView:@"You can't use this account on this device."];
            }
            
        } else {
            NSString *errorString = [[error userInfo] objectForKey:@"error"];
            int  errorCode = [[[error userInfo] objectForKey:@"code"]intValue];
            if (errorCode == 100)
            {
                errorString = @"Ops! You don’t have an internet connection.";
            }
            [self createAlertView:errorString];
        }
        [self.hud removeFromSuperview];
    }];
//    [self loginSuccess];
}
-(void)loginSuccess{
    [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"login"];
    [self performSegueWithIdentifier:@"mainViewSegueId" sender:self];
}
//============================================
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    float keyboardHeigh = 216;
    float offset;
    offset =  keyboardHeigh - (self.view.bounds.size.height - pwdView.frame.origin.y - textField.frame.size.height);
    if (offset > 0) {
        CGRect rect = CGRectMake(0, -offset - 20, self.view.frame.size.width, self.view.frame.size.height);
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        self.view.frame = rect;
        [UIView commitAnimations];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    self.view.frame = rect;
    [UIView commitAnimations];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
//////////////////////////
- (void)createAlertView:(NSString *)message {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message" message:message delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
    [alert show];
}

@end
