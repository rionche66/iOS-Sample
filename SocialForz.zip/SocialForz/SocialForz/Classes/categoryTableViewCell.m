//
//  categoryTableViewCell.m
//  SocialForz
//
//  Created by Bluesky on 4/13/15.
//  Copyright (c) 2015 Bluesky. All rights reserved.
//

#import "categoryTableViewCell.h"

@implementation categoryTableViewCell
@synthesize titleLabel, selectedImgView;
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
