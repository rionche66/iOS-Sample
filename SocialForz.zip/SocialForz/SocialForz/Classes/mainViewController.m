//
//  mainViewController.m
//  SocialForz
//
//  Created by Bluesky on 4/11/15.
//  Copyright (c) 2015 Bluesky. All rights reserved.
//

#import "mainViewController.h"
#import <CoreImage/CoreImage.h>
#import <ImageIO/ImageIO.h>
#import <AssertMacros.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <QuartzCore/QuartzCore.h>
#import <AVFoundation/AVFoundation.h>
#import <Parse/Parse.h>
#import "CLImageEditor.h"
#import "CHTumblrMenuView.h"
#import "UIImage+Resize.h"
#import "AppDelegate.h"
#import "categoryTableViewCell.h"

#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define kBitmapInfo       kCGImageAlphaPremultipliedLast

#pragma mark-

static const NSString *AVCaptureStillImageIsCapturingStillImageContext = @"AVCaptureStillImageIsCapturingStillImageContext";

static CGFloat DegreesToRadians(CGFloat degrees) {return degrees * M_PI / 180;};
static CGContextRef CreateCGBitmapContextForSize(CGSize size);
static CGContextRef CreateCGBitmapContextForSize(CGSize size)
{
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    int             bitmapBytesPerRow;
    
    bitmapBytesPerRow = (size.width * 4);
    CGBitmapInfo bitmapInfo = (CGBitmapInfo) kBitmapInfo;
    colorSpace = CGColorSpaceCreateDeviceRGB();
    context = CGBitmapContextCreate (NULL,
                                     size.width,
                                     size.height,
                                     8,      // bits per component
                                     bitmapBytesPerRow,
                                     colorSpace,
                                     bitmapInfo);
    CGContextSetAllowsAntialiasing(context, NO);
    CGColorSpaceRelease( colorSpace );
    return context;
}

#pragma mark-

@interface UIImage (RotationMethods)
- (UIImage *)imageRotatedByDegrees:(CGFloat)degrees;
@end

@implementation UIImage (RotationMethods)

- (UIImage *)imageRotatedByDegrees:(CGFloat)degrees
{
    // calculate the size of the rotated view's containing box for our drawing space
    UIView *rotatedViewBox = [[UIView alloc] initWithFrame:CGRectMake(0,0,self.size.width, self.size.height)];
    CGAffineTransform t = CGAffineTransformMakeRotation(DegreesToRadians(degrees));
    rotatedViewBox.transform = t;
    CGSize rotatedSize = rotatedViewBox.frame.size;
    
    
    // Create the bitmap context
    UIGraphicsBeginImageContext(rotatedSize);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
    // Move the origin to the middle of the image so we will rotate and scale around the center.
    CGContextTranslateCTM(bitmap, rotatedSize.width/2, rotatedSize.height/2);
    
    //   // Rotate the image context
    CGContextRotateCTM(bitmap, DegreesToRadians(degrees));
    
    // Now, draw the rotated/scaled image into the context
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-self.size.width / 2, -self.size.height / 2, self.size.width, self.size.height), [self CGImage]);
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
    
}

@end

#pragma mark-

@interface mainViewController (InternalMethods)
<CLImageEditorDelegate>
- (void)setupAVCapture;
- (void)teardownAVCapture;
- (void)drawFaceBoxesForFeatures:(NSArray *)features forVideoBox:(CGRect)clap orientation:(UIDeviceOrientation)orientation;
@end

@interface mainViewController (){
    NSArray *allowedCategories;
    NSArray *objSkins;
    NSArray *skinCounts;
    PFFile *skinFile;
    UIImage *originImg;
}
@end

@implementation mainViewController

@synthesize imageTakeData,sharingImage,documentController, dataSkin, categoryTableView;

/////////////////////////////
- (void)setupAVCapture
{
    NSError *error = nil;
    
    AVCaptureSession *session = [AVCaptureSession new];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        [session setSessionPreset:AVCaptureSessionPresetMedium];
    else
        [session setSessionPreset:AVCaptureSessionPresetPhoto];
    
    // Select a video device, make an input
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    AVCaptureDeviceInput *deviceInput = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    
    
    isUsingFrontFacingCamera = NO;
    if ( [session canAddInput:deviceInput] )
        [session addInput:deviceInput];
    
    // Make a still image output
    stillImageOutput = [AVCaptureStillImageOutput new];
//    [stillImageOutput addObserver:self forKeyPath:@"capturingStillImage" options:NSKeyValueObservingOptionNew context:(__bridge void *)(AVCaptureStillImageIsCapturingStillImageContext)];
    if ( [session canAddOutput:stillImageOutput] )
        [session addOutput:stillImageOutput];
    
    // Make a video data output
    videoDataOutput = [AVCaptureVideoDataOutput new];
    
    // we want BGRA, both CoreGraphics and OpenGL work well with 'BGRA'
    NSDictionary *rgbOutputSettings = [NSDictionary dictionaryWithObject:
                                       [NSNumber numberWithInt:kCMPixelFormat_32BGRA] forKey:(id)kCVPixelBufferPixelFormatTypeKey];
    [videoDataOutput setVideoSettings:rgbOutputSettings];
    [videoDataOutput setAlwaysDiscardsLateVideoFrames:YES]; // discard if the data output queue is blocked (as we process the still image)
    
    
    videoDataOutputQueue = dispatch_queue_create("VideoDataOutputQueue", DISPATCH_QUEUE_SERIAL);
    [videoDataOutput setSampleBufferDelegate:self queue:videoDataOutputQueue];
    
    if ( [session canAddOutput:videoDataOutput] )
        [session addOutput:videoDataOutput];
    [[videoDataOutput connectionWithMediaType:AVMediaTypeVideo] setEnabled:NO];
    
    //effectiveScale = 2.0;
    previewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:session];
    [previewLayer setBackgroundColor:[[UIColor whiteColor] CGColor]];
    [previewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
    CALayer *rootLayer = [previewView layer];
    [rootLayer setMasksToBounds:YES];
    [previewLayer setFrame:[rootLayer bounds]];
    [rootLayer addSublayer:previewLayer];
    [session startRunning];
    
bail:
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Failed with error %d", (int)[error code]]
                                                            message:[error localizedDescription]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Dismiss"
                                                  otherButtonTitles:nil];
        [alertView show];
        
        [self teardownAVCapture];
    }
}


- (void)teardownAVCapture
{
    AVCaptureDevice* device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    
    if(!input) {
        // running on simulator or something else without camera
        NSLog(@"camera is not found");
        //TODO
    }
    else {
        if (videoDataOutputQueue)
            
//            [stillImageOutput removeObserver:self forKeyPath:@"isCapturingStillImage"];
        
        [previewLayer removeFromSuperlayer];
    }
    
    
}

// perform a flash bulb animation using KVO to monitor the value of the capturingStillImage property of the AVCaptureStillImageOutput class
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ( context == (__bridge void *)(AVCaptureStillImageIsCapturingStillImageContext) ) {
        BOOL isCapturingStillImage = [[change objectForKey:NSKeyValueChangeNewKey] boolValue];
        
        if ( isCapturingStillImage ) {
            // do flash bulb like animation
            flashView = [[UIView alloc] initWithFrame:[previewView frame]];
            [flashView setBackgroundColor:[UIColor whiteColor]];
            [flashView setAlpha:0.f];
            [[[self view] window] addSubview:flashView];
            
            [UIView animateWithDuration:.4f
                             animations:^{
                                 [flashView setAlpha:1.f];
                             }
             ];
        }
        else {
            [UIView animateWithDuration:.4f
                             animations:^{
                                 [flashView setAlpha:0.f];
                             }
                             completion:^(BOOL finished){
                                 [flashView removeFromSuperview];
                                 
                                 flashView = nil;
                             }
             ];
        }
    }
}

// utility routing used during image capture to set up capture orientation
//- (AVCaptureVideoOrientation)avOrientationForDeviceOrientation:(UIDeviceOrientation)deviceOrientation
//{
//    AVCaptureVideoOrientation result;
//    if ( deviceOrientation == UIDeviceOrientationLandscapeLeft )
//        result = AVCaptureVideoOrientationLandscapeRight;
//    //else
//    else if ( deviceOrientation == UIDeviceOrientationLandscapeRight )
//        result = AVCaptureVideoOrientationLandscapeLeft;
//    else
//        result = AVCaptureVideoOrientationPortrait;
//    
//    return result;
//}

// utility routine to create a new image with the red square overlay with appropriate orientation
// and return the new composited image which can be saved to the camera roll
- (CGImageRef)newSquareOverlayedImageForFeatures:(NSArray *)features
                                       inCGImage:(CGImageRef)backgroundImage
                                 withOrientation:(UIDeviceOrientation)orientation
                                     frontFacing:(BOOL)isFrontFacing
{
    CGImageRef returnImage = NULL;
    CGRect backgroundImageRect = CGRectMake(0., 0., CGImageGetWidth(backgroundImage), CGImageGetHeight(backgroundImage));
    CGContextRef bitmapContext = CreateCGBitmapContextForSize(backgroundImageRect.size);
    CGContextClearRect(bitmapContext, backgroundImageRect);
    CGContextDrawImage(bitmapContext, backgroundImageRect, backgroundImage);
    //CGFloat rotationDegrees = 0.;
    
    switch (orientation) {
        case UIDeviceOrientationPortrait:
            //	rotationDegrees = -90.;
            break;
        case UIDeviceOrientationPortraitUpsideDown:
            //	rotationDegrees = 90.;
            break;
        case UIDeviceOrientationLandscapeLeft:
            //if (isFrontFacing) rotationDegrees = 180.;
            //else rotationDegrees = 0.;
            break;
        case UIDeviceOrientationLandscapeRight:
            //if (isFrontFacing) rotationDegrees = 0.;
            //	else rotationDegrees = 180.;
            break;
        case UIDeviceOrientationFaceUp:
        case UIDeviceOrientationFaceDown:
        default:
            break; // leave the layer in its last known orientation
    }
    
    return returnImage;
    
}

// utility routine used after taking a still image to write the resulting image to the camera roll
- (BOOL)writeCGImageToCameraRoll:(CGImageRef)cgImage withMetadata:(NSDictionary *)metadata
{
    CFMutableDataRef destinationData = CFDataCreateMutable(kCFAllocatorDefault, 0);
    CGImageDestinationRef destination = CGImageDestinationCreateWithData(destinationData,
                                                                         CFSTR("public.jpeg"),
                                                                         1,
                                                                         NULL);
    BOOL success = (destination != NULL);
    //require(success, bail);
    
    const float JPEGCompQuality = 0.99f; // JPEGHigherQuality
    CFMutableDictionaryRef optionsDict = NULL;
    CFNumberRef qualityNum = NULL;
    
    qualityNum = CFNumberCreate(0, kCFNumberFloatType, &JPEGCompQuality);
    if ( qualityNum ) {
        optionsDict = CFDictionaryCreateMutable(0, 0, &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
        if ( optionsDict )
            CFDictionarySetValue(optionsDict, kCGImageDestinationLossyCompressionQuality, qualityNum);
        CFRelease( qualityNum );
    }
    
    CGImageDestinationAddImage( destination, cgImage, optionsDict );
    success = CGImageDestinationFinalize( destination );
    
    if ( optionsDict )
        CFRelease(optionsDict);
    
    //require(success, bail);
    
    CFRetain(destinationData);
    ALAssetsLibrary *library = [ALAssetsLibrary new];
    [library writeImageDataToSavedPhotosAlbum:(__bridge id)destinationData metadata:metadata completionBlock:^(NSURL *assetURL, NSError *error) {
        if (destinationData)
            CFRelease(destinationData);
    }];
    
    
    
bail:
    if (destinationData)
        CFRelease(destinationData);
    if (destination)
        CFRelease(destination);
    return success;
}

// utility routine to display error aleart if takePicture fails
- (void)displayErrorOnMainQueue:(NSError *)error withMessage:(NSString *)message
{
    dispatch_async(dispatch_get_main_queue(), ^(void) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@ (%d)", message, (int)[error code]]
                                                            message:[error localizedDescription]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Dismiss"
                                                  otherButtonTitles:nil];
        [alertView show];
        
    });
}

+ (CGRect)videoPreviewBoxForGravity:(NSString *)gravity frameSize:(CGSize)frameSize apertureSize:(CGSize)apertureSize
{
    CGFloat apertureRatio = apertureSize.height / apertureSize.width;
    CGFloat viewRatio = frameSize.width / frameSize.height;
    
    CGSize size = CGSizeZero;
    if ([gravity isEqualToString:AVLayerVideoGravityResizeAspectFill]) {
        if (viewRatio > apertureRatio) {
            size.width = frameSize.width;
            size.height = apertureSize.width * (frameSize.width / apertureSize.height);
        } else {
            size.width = apertureSize.height * (frameSize.height / apertureSize.width);
            size.height = frameSize.height;
        }
    } else if ([gravity isEqualToString:AVLayerVideoGravityResizeAspect]) {
        if (viewRatio > apertureRatio) {
            size.width = apertureSize.height * (frameSize.height / apertureSize.width);
            size.height = frameSize.height;
        } else {
            size.width = frameSize.width;
            size.height = apertureSize.width * (frameSize.width / apertureSize.height);
        }
    } else if ([gravity isEqualToString:AVLayerVideoGravityResize]) {
        size.width = frameSize.width;
        size.height = frameSize.height;
    }
    
    CGRect videoBox;
    videoBox.size = size;
    if (size.width < frameSize.width)
        videoBox.origin.x = (frameSize.width - size.width) / 1;
    else
        videoBox.origin.x = (size.width - frameSize.width) / 1;
    
    if ( size.height < frameSize.height )
        videoBox.origin.y = (frameSize.height - size.height) / 1;
    else
        videoBox.origin.y = (size.height - frameSize.height) / 1;
    
    return videoBox;
}


- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection
{
    
    CFDictionaryRef attachments = CMCopyDictionaryOfAttachments(kCFAllocatorDefault, sampleBuffer, kCMAttachmentMode_ShouldPropagate);
    
    
    if (attachments)
        CFRelease(attachments);
    NSDictionary *imageOptions = nil;
    
    
    UIDeviceOrientation curDeviceOrientation = [[UIDevice currentDevice] orientation];
    int exifOrientation = 0;
    
    
    enum {
        PHOTOS_EXIF_0ROW_TOP_0COL_LEFT			= 1, //   1  =  0th row is at the top, and 0th column is on the left (THE DEFAULT).
        PHOTOS_EXIF_0ROW_TOP_0COL_RIGHT			= 2, //   2  =  0th row is at the top, and 0th column is on the right.
        PHOTOS_EXIF_0ROW_BOTTOM_0COL_RIGHT      = 3, //   3  =  0th row is at the bottom, and 0th column is on the right.
        PHOTOS_EXIF_0ROW_BOTTOM_0COL_LEFT       = 4, //   4  =  0th row is at the bottom, and 0th column is on the left.
        PHOTOS_EXIF_0ROW_LEFT_0COL_TOP          = 5, //   5  =  0th row is on the left, and 0th column is the top.
        PHOTOS_EXIF_0ROW_RIGHT_0COL_TOP         = 6, //   6  =  0th row is on the right, and 0th column is the top.
        PHOTOS_EXIF_0ROW_RIGHT_0COL_BOTTOM      = 7, //   7  =  0th row is on the right, and 0th column is the bottom.
        PHOTOS_EXIF_0ROW_LEFT_0COL_BOTTOM       = 8  //   8  =  0th row is on the left, and 0th column is the bottom.
    };
    
    switch (curDeviceOrientation) {
        case UIDeviceOrientationPortraitUpsideDown:  // Device oriented vertically, home button on the top
            exifOrientation = PHOTOS_EXIF_0ROW_RIGHT_0COL_TOP;
            break;
        case UIDeviceOrientationLandscapeLeft:       // Device oriented horizontally, home button on the right
            if (isUsingFrontFacingCamera)
                exifOrientation = PHOTOS_EXIF_0ROW_RIGHT_0COL_TOP;
            else
                exifOrientation = PHOTOS_EXIF_0ROW_RIGHT_0COL_TOP;
            break;
        case UIDeviceOrientationLandscapeRight:      // Device oriented horizontally, home button on the left
            if (isUsingFrontFacingCamera)
                exifOrientation = PHOTOS_EXIF_0ROW_RIGHT_0COL_TOP;
            else
                exifOrientation = PHOTOS_EXIF_0ROW_RIGHT_0COL_TOP;
            break;
        case UIDeviceOrientationPortrait:            // Device oriented vertically, home button on the bottom
        default:
            exifOrientation = PHOTOS_EXIF_0ROW_RIGHT_0COL_TOP;
            break;
    }
    
    imageOptions = [NSDictionary dictionaryWithObject:[NSNumber numberWithInt:exifOrientation] forKey:CIDetectorImageOrientation];
    
    dispatch_async(dispatch_get_main_queue(), ^(void) {
        
    });
}


- (void)dealloc
{
    [self teardownAVCapture];
}
/////////////////////////////
#pragma mark - View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    is_flash = YES;
    selected_categoryNum = 0;
    is_share = NO;
    [darkView setHidden:YES];
    [trashBtn setEnabled:NO];
    //
    allowedCategories = [PFUser currentUser][@"category"];
    
    //
    
    skinWidth = self.view.bounds.size.width;
    
    categoryView.layer.cornerRadius = 16.0f;
    categoryView.layer.masksToBounds = YES;
    
    sharingView.layer.cornerRadius = 16.0f;
    sharingView.layer.masksToBounds = YES;
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget: self action:@selector(doSingleTap)];
    singleTap.numberOfTapsRequired = 1;
    [shareView addGestureRecognizer:singleTap];
    
    filterScroll.delegate = self;
    
    _vkontakte = [Vkontakte sharedInstance];
    _vkontakte.delegate = self;
    
    
     NSTimer* myTimer = [NSTimer scheduledTimerWithTimeInterval: 0.5 target: self
                                                       selector: @selector(init_add_skin) userInfo: nil repeats: NO];
}

-(void)setupCamera{
    
}

-(void)doSingleTap{
//    [defaultView setImage:[UIImage imageNamed:@"clearImage.png"]];
//    [self setTakeBtnImg:2];
}

- (void)init_add_skin{
    [self setupAVCapture];
    [self addSkins:0];
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}
- (void)viewWillAppear:(BOOL)animated
{
    
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    if ( [gestureRecognizer isKindOfClass:[UIPinchGestureRecognizer class]] ) {
        beginGestureScale = effectiveScale;
    }
    return YES;
}

///////////////////////////add skin/////////////////////////////
-(void)addSkins:(int)num{
    for (UIView * view in filterScroll.subviews) {
        [view removeFromSuperview];
    }

    NSString *categoryName = allowedCategories[num];
    PFQuery *query = [PFQuery queryWithClassName:@"Skin"];
    [query whereKey:@"category" equalTo:categoryName];
    objSkins = [query findObjects];
    
    count_skins = (int)[objSkins count];
    
    filterScroll.contentSize = CGSizeMake(skinWidth * count_skins, skinWidth);
    filterScroll.pagingEnabled = YES;
    
    for (int i = 0; i < count_skins; i++) {
        UIImageView *skinView = [[UIImageView alloc] initWithFrame:CGRectMake(skinWidth * i, 0, skinWidth, skinWidth)];
        skinView.contentMode = UIViewContentModeScaleAspectFit;
        skinView.tag = i+1;
        [filterScroll addSubview:skinView];
    }
    
    NSLog(@"Start Loading:0");
    
    skinFile = [objSkins[0] objectForKey:@"image"];
    [skinFile getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
        UIImageView *iv = (UIImageView *)[filterScroll viewWithTag:1];
        iv.image = [UIImage imageWithData:data];
        NSLog(@"Image Loaded:%ld", (long)pageCrl.currentPage);
        skinFile = nil;
    }];
    
    pageCrl.numberOfPages = count_skins;
    pageCrl.currentPage = 0;
    filterScroll.contentOffset = CGPointMake(0, 0);
}
///////////////////////////////////////////////////////////////////

- (void)presentImageEditorWithImage:(UIImage*)imageEdits
{
    CLImageEditor *editor = [[CLImageEditor alloc] initWithImage:imageEdits];
    editor.delegate = self;
    
    [self presentViewController:editor animated:YES completion:nil];
}

- (void)imageEditor:(CLImageEditor *)editor didFinishEdittingWithImage:(UIImage *)imagez
{
    [defaultView setImage:imagez];
    [editor dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)turnOffBtnClicked:(id)sender {
    [[NSUserDefaults standardUserDefaults] setInteger:2 forKey:@"login"];
    AppDelegate *del = [UIApplication sharedApplication].delegate;
    del.window.rootViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"loginVC"];
    
}

- (IBAction)flashBtnClicked:(id)sender {
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    if (captureDeviceClass != nil) {
        AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        if ([device hasTorch] && [device hasFlash]){
            
            [device lockForConfiguration:nil];
            if (!is_flash) {
                [device setTorchMode:AVCaptureTorchModeOn];
                [device setFlashMode:AVCaptureFlashModeOn];
                [flashBtn setImage:[UIImage imageNamed:@"button-actve-flash.png"] forState:UIControlStateNormal];
                is_flash = YES;
            } else {
                [device setTorchMode:AVCaptureTorchModeOff];
                [device setFlashMode:AVCaptureFlashModeOff];
                [flashBtn setImage:[UIImage imageNamed:@"button-flash.png"] forState:UIControlStateNormal];
                is_flash = NO;
            }
            [device unlockForConfiguration];
        }
    }
}

- (IBAction)turnCameraBtnClicked:(id)sender {
    AVCaptureDevicePosition desiredPosition;
    if (isUsingFrontFacingCamera)
        desiredPosition = AVCaptureDevicePositionBack;
    else
        desiredPosition = AVCaptureDevicePositionFront;
    
    for (AVCaptureDevice *d in [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo]) {
        if ([d position] == desiredPosition) {
            [[previewLayer session] beginConfiguration];
            AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:d error:nil];
            for (AVCaptureInput *oldInput in [[previewLayer session] inputs]) {
                [[previewLayer session] removeInput:oldInput];
            }
            [[previewLayer session] addInput:input];
            [[previewLayer session] commitConfiguration];
            break;
        }
    }
    isUsingFrontFacingCamera = !isUsingFrontFacingCamera;
    [defaultView setImage:[UIImage imageNamed:@"clearImage.png"]];
}

- (IBAction)trashBtnClicked:(id)sender {
    AVCaptureDevicePosition desiredPosition;
    
    for (AVCaptureDevice *d in [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo]) {
        if ([d position] == desiredPosition) {
            [[previewLayer session] beginConfiguration];
            AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:d error:nil];
            for (AVCaptureInput *oldInput in [[previewLayer session] inputs]) {
                [[previewLayer session] removeInput:oldInput];
            }
            [[previewLayer session] addInput:input];
            [[previewLayer session] commitConfiguration];
            break;
        }
    }
    [defaultView setImage:[UIImage imageNamed:@"clearImage.png"]];
    [self setTakeBtnImg:2];
}

- (IBAction)rollBtnClicked:(id)sender {
    //gallery
    albumPhoto = [[UIImagePickerController alloc]init];
    albumPhoto.delegate = self;
    [albumPhoto setSourceType: UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:albumPhoto animated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)infoz{
    
    UIImage *imgs = [infoz objectForKey:UIImagePickerControllerOriginalImage];
    [defaultView setImage:imgs];
    [self dismissViewControllerAnimated:YES completion:nil];
    [self setTakeBtnImg:1];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (IBAction)takeBtnClicked:(id)sender {
    if (is_share) {
        if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]) {
            if ([[UIScreen mainScreen] scale] == 2.0) {
                UIGraphicsBeginImageContextWithOptions((shareView.frame.size), YES, 2.0);
            } else {
                UIGraphicsBeginImageContext(shareView.frame.size);
            }
        } else {
            UIGraphicsBeginImageContext(shareView.frame.size);
        }
//        UIGraphicsBeginImageContext(CGSizeMake(960, 960));

        CGSize constraint = CGSizeMake(960, 960);
        
//        UIGraphicsBeginImageContext(defaultView.frame.size);
//        [defaultView.layer renderInContext:UIGraphicsGetCurrentContext()];
//        UIImage *viewImage1 = UIGraphicsGetImageFromCurrentImageContext();
//        UIImage* scaledImg2 = [viewImage1 resizedImageToSize:constraint];
//        originImg = viewImage1;
//        UIGraphicsEndImageContext();
        
//        UIGraphicsBeginImageContext(shareView.frame.size);
        [shareView.layer renderInContext:UIGraphicsGetCurrentContext()];
        UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
        UIImage* scaledImg1 = [viewImage resizedImageToSize:constraint];
        sharingImage = scaledImg1;
        UIGraphicsEndImageContext();
        
        UIImageWriteToSavedPhotosAlbum(originImg, nil, nil, nil);
        UIImageWriteToSavedPhotosAlbum(sharingImage, nil, nil, nil);
        
        CGRect rect = CGRectMake(sharingView.frame.origin.x, self.view.bounds.size.height - 200, sharingView.frame.size.width, sharingView.frame.size.height);
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        [darkView setHidden:NO];
        darkView.alpha = 0.7;
        sharingView.frame = rect;
        [UIView commitAnimations];
        
    }else{
        AVCaptureConnection *stillImageConnection = [stillImageOutput connectionWithMediaType:AVMediaTypeVideo];
        
        [stillImageOutput setOutputSettings:[NSDictionary dictionaryWithObject:AVVideoCodecJPEG
                                                                        forKey:AVVideoCodecKey]];
        
        [stillImageOutput captureStillImageAsynchronouslyFromConnection:stillImageConnection
                                                      completionHandler:^(CMSampleBufferRef imageDataSampleBuffer, NSError *error) {
                                                          if (error) {
                                                              [self displayErrorOnMainQueue:error withMessage:@"Take picture failed"];
                                                          }
                                                          else {
                                                              
                                                              // trivial simple JPEG case
                                                              NSData *jpegData = [AVCaptureStillImageOutput jpegStillImageNSDataRepresentation:imageDataSampleBuffer];
                                                              CFDictionaryRef attachments = CMCopyDictionaryOfAttachments(kCFAllocatorDefault,                                                                                                                      imageDataSampleBuffer,                                                                                                                      kCMAttachmentMode_ShouldPropagate);
                                                              //  ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
                                                              imageTakeData = [UIImage imageWithData:jpegData];
                                                              [defaultView setImage:imageTakeData];
                                                              if (attachments)
                                                                  CFRelease(attachments);
                                                              
                                                          }
                                                      }
         
         ];
        [self setTakeBtnImg:1];
    }
}

- (IBAction)categoryBtnClicked:(id)sender {
    [categoryTableView reloadData];
    // select cagegory of skins
    CGRect rect = CGRectMake(self.view.bounds.size.width - 200, 0, categoryView.frame.size.width, categoryView.frame.size.height);
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    [darkView setHidden:NO];
    darkView.alpha = 0.7;
    categoryView.frame = rect;
    [UIView commitAnimations];
}

- (void)setTakeBtnImg:(int)type{
    if (type == 1) {
        is_share = YES;
        [takeBtn setImage:[UIImage imageNamed:@"button-sharepic.png"] forState:UIControlStateNormal];
        
        [flashBtn setEnabled:NO];
        [turnCameraBtn setEnabled:NO];
        [trashBtn setEnabled:YES];
    } else {
        is_share = NO;
        [takeBtn setImage:[UIImage imageNamed:@"button-takepicture.png"] forState:UIControlStateNormal];
        
        [flashBtn setEnabled:YES];
        [turnCameraBtn setEnabled:YES];
        [trashBtn setEnabled:NO];
    }
}
////////////////
#pragma mark - VkontakteDelegate

- (void)vkontakteDidFailedWithError:(NSError *)error
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)showVkontakteAuthController:(UIViewController *)controller
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        controller.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    
    [self presentViewController:controller animated:YES completion:nil];
}

- (void)vkontakteAuthControllerDidCancelled
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)vkontakteDidFinishLogin:(Vkontakte *)vkontakte
{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)vkontakteDidFinishLogOut:(Vkontakte *)vkontakte
{
    NSLog(@"%@", vkontakte);
}

- (void)vkontakteDidFinishGettinUserInfo:(NSDictionary *)infoz
{
    NSLog(@"%@", infoz);
}

- (void)vkontakteDidFinishPostingToWall:(NSDictionary *)responce
{
    NSLog(@"%@", responce);
    
    NSString *downTitle = [[NSString alloc]initWithFormat:@"Post send"];
    
    
    UIAlertView *alert2 = [[UIAlertView alloc] initWithTitle:downTitle
                                                     message:@"successfully..."
                                                    delegate: self
                                           cancelButtonTitle:@"Ok"
                                           otherButtonTitles: nil];
    
    [alert2 show];
    
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    // Update the page when more than 50% of the previous/next page is visible
    CGFloat pageWidth = filterScroll.frame.size.width;
    CGFloat pageWidtall =  filterScroll.contentSize.width;
    int page = floor((filterScroll.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    
    if(page == pageCrl.currentPage){
        return;
    }
    
    int allpage = floor(pageWidtall/skinWidth);
    // NSLog(@"ALL PAGE - %d",allpage);
    pageCrl.currentPage = page;
    pageCrl.numberOfPages = allpage;
    [self loadCurrentImage];
}

- (IBAction)changePage {
    // update the scroll view to the appropriate page
    CGRect frame;
    frame.origin.x = filterScroll.frame.size.width * pageCrl.currentPage;
    frame.origin.y = 0;
    frame.size = filterScroll.frame.size;
    [filterScroll scrollRectToVisible:frame animated:YES];
    
    [self loadCurrentImage];
    
}

- (void)loadCurrentImage{
    
    if(skinFile != nil){
        [skinFile cancel];
        skinFile = nil;
        NSLog(@"Cancelled!");
    }
    
    skinFile = [objSkins[pageCrl.currentPage] objectForKey:@"image"];
    NSLog(@"Image Loading...");
    [skinFile getDataInBackgroundWithBlock:^(NSData *data, NSError *error) {
        UIImageView *iv = (UIImageView *)[filterScroll viewWithTag:pageCrl.currentPage + 1];
        iv.image = [UIImage imageWithData:data];
        NSLog(@"Image Loaded:%ld", (long)pageCrl.currentPage);
        skinFile = nil;
    }];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    // pageControlBeingUsed = NO;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    // pageControlBeingUsed = NO;
}
- (IBAction)cancelBtnClicked:(id)sender {
    [self push_sharingView];
}

- (IBAction)facebookBtnClicked:(id)sender {
    [self push_sharingView];
    [self saveToparse];
    
    SLComposeViewController *mySLComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    [mySLComposerSheet setInitialText:[NSString stringWithFormat:@"%@ shared a picture via SocialForz.",[PFUser currentUser].username]];
//    CGSize constraint = CGSizeMake(960, 960);
//    UIImage* scaledImgH = [sharingImage resizedImageToSize:constraint];
    [mySLComposerSheet addImage:sharingImage];
    
    [self presentViewController:mySLComposerSheet animated:YES completion:^{
        
    }];
}

- (IBAction)twitterBtnClicked:(id)sender {
    [self push_sharingView];
    [self saveToparse];
    
    SLComposeViewController *mySLComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    [mySLComposerSheet setInitialText:[NSString stringWithFormat:@"%@ shared a picture via SocialForz.",[PFUser currentUser].username]];
    
//    CGSize constraint = CGSizeMake(960, 960);
//    UIImage* scaledImgH = [sharingImage resizedImageToSize:constraint];
    [mySLComposerSheet addImage:sharingImage];
    
    [self presentViewController:mySLComposerSheet animated:YES completion:^{
        
    }];
}

- (IBAction)instagramBtnClicked:(id)sender {
    [self push_sharingView];
    [self saveToparse];
    
    UIImage* instaImage = sharingImage;
//    CGSize constraint = CGSizeMake(960, 960);
//    UIImage* scaledImgH = [instaImage resizedImageToSize:constraint];
   
    NSString* imagePath = [NSString stringWithFormat:@"%@/image.igo", [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]];
    [[NSFileManager defaultManager] removeItemAtPath:imagePath error:nil];
    [UIImagePNGRepresentation(instaImage) writeToFile:imagePath atomically:YES];
    NSLog(@"image size: %@", NSStringFromCGSize(instaImage.size));
    documentController = [[UIDocumentInteractionController alloc]init];
    documentController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:imagePath]];
    documentController.delegate=self;
    NSString    * savePath  = [NSString stringWithFormat:@"%@ shared a picture via SocialForz.",[PFUser currentUser].username];
    documentController.annotation=[NSDictionary dictionaryWithObjectsAndKeys:savePath,@"InstagramCaption", nil];
    documentController.UTI = @"com.instagram.exclusivegram";
    // [docController presentOpenInMenuFromRect:self.view.frame inView:self.view animated:YES];
    [documentController presentOpenInMenuFromRect:CGRectZero
                                           inView:self.view
                                         animated:YES];
}

- (IBAction)whatsappBtnClicked:(id)sender {
    [self push_sharingView];
    [self saveToparse];
    
    if ([[UIApplication sharedApplication] canOpenURL: [NSURL URLWithString:@"whatsapp://app"]]){
        
        UIImage     * iconImage = sharingImage;
        NSString    * savePath  = [NSString stringWithFormat:@"%@ shared a picture via SocialForz.",[PFUser currentUser].username];
        
        [UIImageJPEGRepresentation(iconImage, 1.0) writeToFile:savePath atomically:YES];
        
        documentController = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:savePath]];
        documentController.UTI = @"net.whatsapp.image";
        documentController.delegate = self;
        
        [documentController presentOpenInMenuFromRect:CGRectMake(0, 0, 0, 0) inView:self.view animated: YES];
        
    }
}

-(void)saveToparse{
    
//    CGSize constraint = CGSizeMake(960, 960);
//    UIImage* scaledImg1 = [sharingImage resizedImageToSize:constraint];
//    UIImage* scaledImg2 = [originImg resizedImageToSize:constraint];
    
    NSData *avartarData1 = UIImageJPEGRepresentation(sharingImage, 0.7);//UIImagePNGRepresentation(sharingImage);
    PFFile *skinedimgFile = [PFFile fileWithName:@"img" data:avartarData1];
    
//    NSData *avartarData2 = UIImageJPEGRepresentation(scaledImg2, 1.0);
//    PFFile *noSkinimgFile = [PFFile fileWithName:@"img" data:avartarData2];
    
    PFObject *imageObject = [PFObject objectWithClassName:@"Photo"];
    [imageObject setObject:skinedimgFile forKey:@"skined"];
//    [imageObject setObject:noSkinimgFile forKey:@"noSkin"];
    [imageObject setObject:[PFUser currentUser].username forKey:@"username"];
    //3
    [imageObject saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        //4
        if (succeeded){
            //Go back to the wall
            NSLog(@"success save image");
        }
        else{
            NSString *errorString = [[error userInfo] objectForKey:@"error"];
            UIAlertView *errorAlertView = [[UIAlertView alloc] initWithTitle:@"Error" message:errorString delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            [errorAlertView show];
        }
    }];
}

-(void)push_sharingView{
    CGRect rect = CGRectMake(sharingView.frame.origin.x, self.view.bounds.size.height, sharingView.frame.size.width, sharingView.frame.size.height);
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    darkView.alpha = 0.0;
    [darkView setHidden:YES];
    sharingView.frame = rect;
    [UIView commitAnimations];
}

-(void)push_categoryView{
    CGRect rect = CGRectMake(self.view.bounds.size.width, 0, categoryView.frame.size.width, categoryView.frame.size.height);
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    [darkView setHidden: YES];
    darkView.alpha = 0.0;
    categoryView.frame = rect;
    [UIView commitAnimations];
}
//===============================================================================
#pragma mark - UITableViewDataSource
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    //
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tb
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tb numberOfRowsInSection:(NSInteger)section
{
    return [allowedCategories count];
}

- (UITableViewCell *)tableView:(UITableView *)tb cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * strId = @"categoryTableViewCell";
    categoryTableViewCell * newCell = [tb dequeueReusableCellWithIdentifier:strId];
    if( newCell == nil )
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"categoryTableViewCell" owner:self options:nil];
        newCell = [nib objectAtIndex:0];
    }
    NSString * titleStr;
    
    NSString * selectedCategoryStr = allowedCategories[indexPath.row];
    PFQuery *query = [PFQuery queryWithClassName:@"Skin"];
    [query whereKey:@"category" equalTo:selectedCategoryStr];
    NSArray *objSkin = [query findObjects];
    count_skins = (int)[objSkin count];
    
    if (indexPath.row != 0) {
        titleStr = [NSString stringWithFormat:@"CATEGORY%ld(%d)", (long)indexPath.row, count_skins];
    }else{
        titleStr = [NSString stringWithFormat:@"DEFAULT(%d)", count_skins];
    }
    newCell.titleLabel.text = titleStr;
    if (indexPath.row == selected_categoryNum) {
        newCell.selectedImgView.image = [UIImage imageNamed:@"radio-selected-category.png"];
    }else{
        newCell.selectedImgView.image = [UIImage imageNamed:@"radio-unselected-categories.png"];
    }
    return newCell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * strId = @"categoryTableViewCell";

    categoryTableViewCell *selectedcell = [categoryTableView dequeueReusableCellWithIdentifier:strId forIndexPath:indexPath];
    selectedcell.selectedImgView.image = [UIImage imageNamed:@"radio-selected-category.png"];
    
    selected_categoryNum = indexPath.row;
    
    [categoryTableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self push_categoryView];
    
    [self addSkins:(int)selected_categoryNum];
}
- (IBAction)push_view:(id)sender {
    if (sharingView.frame.origin.y < self.view.bounds.size.height) {
        [self push_sharingView];
    }else if (categoryView.frame.origin.x < self.view.bounds.size.width) {
        [self push_categoryView];
    }else{}
}

@end
