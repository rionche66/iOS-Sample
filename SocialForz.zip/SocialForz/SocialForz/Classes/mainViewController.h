//
//  mainViewController.h
//  SocialForz
//
//  Created by Bluesky on 4/11/15.
//  Copyright (c) 2015 Bluesky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreLocation/CoreLocation.h>
#import <Social/Social.h>
#import <Accounts/Accounts.h>
#import <MessageUI/MessageUI.h>
#import "Vkontakte.h"

@class CIDetector;

@interface mainViewController : UIViewController<UIScrollViewDelegate, UIGestureRecognizerDelegate, AVCaptureVideoDataOutputSampleBufferDelegate,  UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIDocumentInteractionControllerDelegate,MFMailComposeViewControllerDelegate,VkontakteDelegate, UITableViewDelegate, UITableViewDataSource>{
    IBOutlet UIButton *flashBtn;
    IBOutlet UIButton *turnCameraBtn;
    IBOutlet UIPageControl *pageCrl;
    IBOutlet UIButton *takeBtn;
    IBOutlet UIButton *trashBtn;
    IBOutlet UIView *mainView;
    
    IBOutlet UIView *previewView;
    IBOutlet UIView *shareView;
    IBOutlet UIView *renderPhotoView;
    IBOutlet UIImageView *defaultView;
    IBOutlet UIScrollView *filterScroll;
    
    ////
    BOOL is_flash;
    NSInteger selected_categoryNum;
    BOOL is_share;
    int count_skins;
    int categoryNum;
    NSArray *categoryCountAry;
    float skinWidth;
    
    AVCaptureVideoPreviewLayer *previewLayer;
    AVCaptureVideoDataOutput *videoDataOutput;
    BOOL detectFaces;
    dispatch_queue_t videoDataOutputQueue;
    AVCaptureStillImageOutput *stillImageOutput;
    UIView *flashView;
    UIImage *square;
    BOOL isUsingFrontFacingCamera;
    CIDetector *faceDetector;
    CGFloat beginGestureScale;
    CGFloat effectiveScale;
    
    UIImagePickerController *albumPhoto;
    UIImagePickerController *takePhoto;
    
//    UIImage *imageTakeData;
//    NSMutableArray *dataSkin;
//    UIImage *sharingImage;
    
    Vkontakte *_vkontakte;
    /////
    IBOutlet UIView *sharingView;
    IBOutlet UIView *categoryView;
    IBOutlet UIView *darkView;
    
}

- (IBAction)turnOffBtnClicked:(id)sender;
- (IBAction)flashBtnClicked:(id)sender;
- (IBAction)turnCameraBtnClicked:(id)sender;
- (IBAction)trashBtnClicked:(id)sender;
- (IBAction)rollBtnClicked:(id)sender;
- (IBAction)takeBtnClicked:(id)sender;
- (IBAction)categoryBtnClicked:(id)sender;
- (IBAction)changePage;

@property (nonatomic,retain)  UIImage *sharingImage;
@property (nonatomic,retain) UIImage *imageTakeData;
@property (nonatomic,retain) NSMutableArray *dataSkin;
@property (retain)UIDocumentInteractionController *documentController;
////
- (IBAction)cancelBtnClicked:(id)sender;
- (IBAction)facebookBtnClicked:(id)sender;
- (IBAction)twitterBtnClicked:(id)sender;
- (IBAction)instagramBtnClicked:(id)sender;
- (IBAction)whatsappBtnClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *categoryTableView;

@end
