//
//  CLImageTools.h
//
//  Created by sho yakushiji on 2013/10/17.
//  Copyright (c) 2013年 CALACULU. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CLImageToolBase.h"

@interface CLImageTools : NSObject

+ (NSArray*)list;

@end
